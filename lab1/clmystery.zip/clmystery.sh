#!/bin/sh
cd Documentos/pcs3616/lab1/
cd clmystery-pt-BR-v2/
ls
cat inicio 
cd misterio/
ls
cat cena-do-crime 
ls
grep PISTA cena-do-crime 
ls
cat pessoas
grep annabel -i pessoas 
ls
cd ruas
ls
cat Vila_Hart 
cd ..
ls
cd ..
ls
cat dica1
cat dica2
cat dica3
ls
cd misterio/
ls
head -n 20 pessoas
cat automoveis 
grep 1,8* automoveis 
cat automoveis 
ls
head automoveis 
head cena-do-crime 
ls
head pessoas 
cd ruas/
ld
ls
head Rua_Mattapan 
head Rua_Haley 
head Vila_Hart 
head Vila_Buckingham 
cd ..
head pessoas
cd ruas/
cat Vila_Hart 
grap LEIA Vila_Buckingham 
grep LEIA Vila_Buckingham 
grep LEIA Rua_Haley 
cd ..
ls
cd entrevistas/
ls
cat entrevista-47246024 
cat entrevista-871877 
cat entrevista-699607 
ls
cd ..
ls
head  automoveis 
grep Honda -i automoveis
cd ..
ls
cat dica4
cat dica5
cat dica6
cat dica7
cat dica8
ls
cd misterio/
ls
head automoveis 
grep -A 5 "L337" automoveis
ls
cd associacoes/
ls
cat AAA Delta_SkyMiles Biblioteca_da_Cidade Museu_da_História_do_Bash | grep "Joe Germuska"
cat AAA Delta_SkyMiles Biblioteca_da_Cidade Museu_da_História_do_Bash | grep "Jacqui Maher"
cat AAA Delta_SkyMiles Biblioteca_da_Cidade Museu_da_História_do_Bash | grep "Rienne Lemeda"
ls
cd ..
ls
cat pessoas | grep Jacqui
cat pessoas | grep Rienne
echo "Rienne Lemeda"


